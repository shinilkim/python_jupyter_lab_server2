# 설치 프로그램
01.01) GIT 설치
https://www.git-scm.com/downloads

01.02) GIT 관리 프로그램
https://www.sourcetreeapp.com/

02.01) DB > MariaDB (설치형 DB)
https://mariadb.com/downloads/

02.02) DB > sqlite (내장형 DB)
https://www.sqlite.org/

02.03) ERD 도구 (학습참조: https://www.en-core.com/board/reference)
https://www.en-core.com/board/download

03.01) 파이썬 v3.9.10
https://www.python.org/downloads/release/python-3910/

04.01) 개발도구 > Visual Studio code
https://code.visualstudio.com/

05.01) PMS(프로젝트 관리)
https://www.projectlibre.com/product/1-alternative-microsoft-project-open-source

05.02) PDF 문서 번역
https://www.onlinedoctranslator.com/ko/translationform

# Python libaray
jupyter
pandas
tensorflow

# 프로젝트 > GIT
1) 프로젝트 GIT 기본 저장소
https://github.com/shinilkim/python_jupyter_server2.git


# 학습 참조
01) 텐서플로워
https://js.tensorflow.org/api/latest/?hl=ko

2) 문제풀기
- 프로그래머
https://programmers.co.kr/learn/challenges?tab=all_challenges

3) 개론
- 인공지능 개론
https://www.youtube.com/watch?v=J6hiz5zfDC0&list=PL1xKqHsVFgvk8nB5kJ3N0fFt3etudUBWt&ab_channel=%EC%84%B8%EC%A2%85%EB%8C%80.%EC%B5%9C%EC%9C%A0%EA%B2%BD%EA%B5%90%EC%88%98
https://www.youtube.com/watch?v=RtOnB8WrHKw&list=PLqpIWUSJxdDn9X17lI-WO56i6WAwx0VzS&ab_channel=%EC%84%B1%EA%B7%A0%EA%B4%80%EB%8C%80%ED%95%99%EA%B5%90%EC%98%A4%ED%95%98%EC%98%81%EA%B5%90%EC%88%98