def a1():
    return "A1"

def a2():
    return "A2"