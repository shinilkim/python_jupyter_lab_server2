/**
지역화폐 발행 및 이용 현황 - 경기도 지역화폐 발행 및 이용 현황 입니다.

https://data.gg.go.kr/portal/data/service/selectServicePage.do?page=1&rows=10&sortColumn=&sortDirection=&infId=6FEDD6KGEJWYCY2G15OY29527318&infSeq=2&order=&loc=&searchWord=%ED%99%94%ED%8F%90
https://openapi.gg.go.kr/RegionMnyPublctUse?KEY=3e9686f9abff44de926e9f87c251d8b7&Type=json&pIndex=1&pSize=1
*/